import cv2
import numpy as np

def SaltNPepper_Noise_method(original_image, error_proportion):
    N = int(np.round(np.prod(original_image.shape) * error_proportion))
    index = np.unravel_index(np.random.permutation(np.prod(original_image.shape))[1:N], original_image.shape)
    Gaussian_Noise_Image = np.copy(original_image)
    Gaussian_Noise_Image[index] = 1 - Gaussian_Noise_Image[index]

    return Gaussian_Noise_Image