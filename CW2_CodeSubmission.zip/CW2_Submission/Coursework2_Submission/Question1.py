#question 1 : ICM with Ising Model
import cv2
import numpy as np
import matplotlib.pyplot as plt
from Gaussian_Noise import Gaussian_Noise_method
from SaltNPepperNoise import SaltNPepper_Noise_method
 
# Reading the original_image
original_image = cv2.imread('pug.png',cv2.IMREAD_GRAYSCALE)

# Image thresholding and printing
original_image = original_image/255.0
original_image[original_image<0.5]=-1
original_image[original_image>=0.5]=1
fig = plt.figure()
ax = fig.add_subplot(131)
ax.imshow(original_image, cmap='gray')
ax.set_title('original')
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)

error_proportion = 0.4
sigma_variance = 0.9

# Gaussinan noise original_image
Gaussian_Noise_Image = Gaussian_Noise_method(original_image, error_proportion, sigma_variance)
ax2 = fig.add_subplot(132)
ax2.imshow(Gaussian_Noise_Image, cmap='gray')
ax2.set_title('gaussian noise')
ax2.get_xaxis().set_visible(False)
ax2.get_yaxis().set_visible(False)

# Salt and Pepper noise original_image
SnP_Noise_Image = SaltNPepper_Noise_method(original_image, error_proportion)
ax3 = fig.add_subplot(133)
ax3.imshow(SnP_Noise_Image, cmap='gray')
ax3.set_title('saltnpepper noise')
ax3.get_xaxis().set_visible(False)
ax3.get_yaxis().set_visible(False)

# Calculation of nearest neighbours
def neighbours(i, j, M, N, size=4):
    if size == 4:
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2)]

        # everywhere else
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)]

        
    if size==8 :
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0), (1,1)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1), (1, N - 2)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0), (M - 2, 1)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1), (M - 2,N - 2)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j), (1, j+1), (1, j-1)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j),(M-2,j-1),(M-2,j+1)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1),(i-1,1),(i+1,1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2),(i+1,N-2),(i+1,N-2)]

        # everywhere else
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1),(i-1,j-1),(i-1,j+1),(i+1,j-1),(i+1,j+1)]
    
    return n
    
beta = 2.1
eta = 1.5
h = 0

def ICM_Model(original_image, number_of_iterations):
    latent_image = np.copy(original_image)
    noisy_image = np.copy(original_image)
    #print 'before threshold', noisy_image
    latent_image[latent_image >= 0.5] = 1
    latent_image[latent_image < 0.5] = -1
    #print 'after threshold',latent_image

    #latent_image = np.copy(noisy_image)

    E_current = total_energy(latent_image, noisy_image)
    
    for t in range(number_of_iterations):
        
        Flag_Value = False
        
        for j in range(latent_image.shape[0]):
            for i in range(latent_image.shape[1]):
                old = latent_image[j][i]
                

                E1, E2, original, flipped = local_energy(E_current, latent_image, noisy_image, j, i)
                
                if E1 < E2:
                    latent_image[j][i] = original
                    E_current = E1
                else:
                    latent_image[j][i] = flipped
                    E_current = E2
                
                
                if old != latent_image[j][i]:
                    Flag_Value = True

        print (Flag_Value)
        print(t)
        if not Flag_Value:
            break

    return latent_image

def total_energy(latent_image, noisy_image):
    E = 0.0

    for j in range(latent_image.shape[0]):
        for i in range(latent_image.shape[1]):
            E += h * latent_image[j, i]

            neighs = neighbours(j, i, latent_image.shape[0], latent_image.shape[1],4)
            E -= beta * sum(latent_image[j, i] * latent_image[neigh_j, neigh_i] for neigh_j, neigh_i in neighs)

            E -= eta * latent_image[j, i] * noisy_image[j, i]

    return E


def local_energy(E1, latent_image, noisy_image, j, i):
    neighs = neighbours(j, i, latent_image.shape[0], latent_image.shape[1],4)

    original = latent_image[j, i]
    flipped = original * -1

    E2 = E1 - (h * original) + (h * flipped)

    E2 = E2 + beta * sum(original * latent_image[neigh_j, neigh_i] for neigh_j, neigh_i in neighs)
    E2 = E2 - beta * sum(flipped * latent_image[neigh_j, neigh_i] for neigh_j, neigh_i in neighs)

    E2 = E2 + (eta * noisy_image[j, i] * original) - (eta * noisy_image[j, i] * flipped)

    return E1, E2, original, flipped


im_out = ICM_Model(SnP_Noise_Image, 50)
fig = plt.figure()
ax = fig.add_subplot(131)
ax.imshow(original_image, cmap='gray')
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)

ax2 = fig.add_subplot(132)
ax2.imshow(SnP_Noise_Image, cmap='gray')
ax2.get_xaxis().set_visible(False)
ax2.get_yaxis().set_visible(False)

ax3 = fig.add_subplot(133)
ax3.imshow(im_out, cmap='gray')
ax3.get_xaxis().set_visible(False)
ax3.get_yaxis().set_visible(False)