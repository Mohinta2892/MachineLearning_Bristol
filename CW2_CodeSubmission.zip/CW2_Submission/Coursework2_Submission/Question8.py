
import itertools
import random

import numpy as np
import cv2
import matplotlib.image as mpimg
import matplotlib.pyplot as plt


def neighbours(i, j, M, N, size=4):
    if size == 4:
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2)]

        # everywhere else
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)]

        
    if size==8 :
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0), (1,1)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1), (1, N - 2)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0), (M - 2, 1)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1), (M - 2,N - 2)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j), (1, j+1), (1, j-1)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j),(M-2,j-1),(M-2,j+1)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1),(i-1,1),(i+1,1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2),(i+1,N-2),(i+1,N-2)]

        # everywhere else
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1),(i-1,j-1),(i-1,j+1),(i+1,j-1),(i+1,j+1)]
    
    return n


def Prior(j, i, fore_mask, back_mask, fLi,  bLi):
    neighs = neighbours(j, i, fore_mask.shape[0], fore_mask.shape[1])
    for neigh_j, neigh_i in neighs:
        if(fore_mask[neigh_j,neigh_i] == 1): 
            fLi *= 0.7
        else:
            fLi*= 0.3
        if(back_mask[neigh_j, neigh_i] == 1):
            bLi *= 0.7
        else:
            bLi *= 0.3
    return fLi, bLi

def Deduce_Likelihood(dist, label, intensities, bins):
    idxs = enumerate(intensities)
    distProbs = []
    for (i, intensity) in idxs:
        bin_edges = bins[label, i, :]
        indexes_binary = 0
        for j in range(0, len(bin_edges)):
            if (bin_edges[j] < float(intensity) and bin_edges[j+1] > float(intensity)):
                indexes_binary = j
        distProbs.append(dist[label, i, indexes_binary])
    return np.prod(distProbs)

    # return np.prod([dist[label, i, intensity] for (i, intensity) in idxs])


# Specificities based on Content in the Coursework Manual
def Seg_Gibbs(original_image, burn_in, iterations, histograms, bins, fore_mask, back_mask):
    latent_x = np.zeros((original_image.shape[0], original_image.shape[1]))

    ## make random estimates for giraffe
    estimates = (np.random.random( (original_image.shape[0], original_image.shape[1]) ) > .5).astype(int)

    total_iterations = burn_in + iterations
    pixel_indices = list(itertools.product(range(original_image.shape[0]),range(original_image.shape[1])))

    for iteration in range(total_iterations):
        print(iteration)

        # Loop over entire grid, using a random order for faster convergence similar to Gibbs in question 3
        random.shuffle(pixel_indices)
        for (i,j) in pixel_indices:
            ## Likelihood for foreground and background
            like_fore = Deduce_Likelihood(histograms, 0, original_image[i,j,:], bins)
            like_back = Deduce_Likelihood(histograms, 1, original_image[i,j,:], bins)
            
            posterior_assumption_Fore, posterior_assumption_Back = Prior(i, j, fore_mask, back_mask, like_fore, like_back)
            
            prob = posterior_assumption_Fore / (posterior_assumption_Fore + posterior_assumption_Back)
            if(np.random.uniform(0, 1) < prob):
                estimates[i,j] = -1
            else:
                estimates[i,j] = 1
        if iteration > burn_in:
            latent_x += estimates
    
    latent_x /= total_iterations

    return latent_x

def Generate_Histogram(original_image, mask):
    r_hist, rbin_edges = np.histogram(original_image[...,0], weights=mask, bins=15, density=True)
    g_hist, gbin_edges = np.histogram(original_image[...,1], weights=mask, bins=15, density=True)
    b_hist, bbin_edges = np.histogram(original_image[...,2], weights=mask, bins=15, density=True)

    return [r_hist, g_hist, b_hist], [rbin_edges, gbin_edges, bbin_edges]

def Extract_Distribution(original_image, fore_mask, back_mask):
    fore_dist, fore_bins = Generate_Histogram(original_image, fore_mask)
    back_dist, back_bins = Generate_Histogram(original_image, back_mask)
    return [fore_dist, back_dist], [fore_bins, back_bins]



image_file = 'bee_test.png'

original_image = np.array(mpimg.imread(image_file))
grayed_image = cv2.imread(image_file,cv2.IMREAD_GRAYSCALE)

fore_mask = np.zeros_like(original_image[:,:,0])
back_mask = np.zeros_like(original_image[:,:,0])

back_mask[grayed_image >= 115] = 1
fore_mask[grayed_image < 100] = 1

fore_mask_copy = np.zeros((original_image.shape[0], original_image.shape[1]))


back_mask_copy = np.zeros((original_image.shape[0], original_image.shape[1]))


fig, axes = plt.subplots(nrows=1, ncols=2)
axes.flat[0].imshow(fore_mask)
fig, axes = plt.subplots(nrows=1, ncols=2)
axes.flat[0].imshow(back_mask)
histograms, bins = Extract_Distribution(original_image, fore_mask, back_mask)
histograms = np.array(histograms)
bins = np.array(bins)

seg_image = Seg_Gibbs(original_image, 0, 2, histograms, bins, fore_mask, back_mask)
seg_image[seg_image >= 0] = 1
seg_image[seg_image < 0]  = -1

fig, axes = plt.subplots(nrows=1, ncols=2)
axes.flat[0].imshow(original_image)
plt.gray()
Original_image = axes.flat[1].imshow(seg_image.astype('float64'), interpolation='nearest')
fig.colorbar(Original_image, ax=axes.ravel().tolist())
plt.show()