import cv2
import numpy as np
import matplotlib.pyplot as plt
from Gaussian_Noise import Gaussian_Noise_method
from SaltNPepperNoise import SaltNPepper_Noise_method

error_proportion = 0.5
sigma_variance = 0.5

Original_image = cv2.imread('pug.png',cv2.IMREAD_GRAYSCALE)
Original_image = Original_image/255.0
Original_image[Original_image<0.5]=-1
Original_image[Original_image>=0.5]=1
fig = plt.figure()
ax = fig.add_subplot(151)
ax.imshow(Original_image, cmap='gray')
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.set_title('original')

'''
Gaussian_Noise_Image = Gaussian_Noise_method(Original_image, error_proportion, sigma_variance)
ax = fig.add_subplot(152)
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.imshow(Gaussian_Noise_Image, cmap='gray')
ax.set_title('gaussian')'''

SnP_Noise_Image = SaltNPepper_Noise_method(Original_image, error_proportion)
ax = fig.add_subplot(152)
ax.imshow(SnP_Noise_Image, cmap='gray')
ax.set_title('saltnpepper')
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)



def neighbours(i, j, M, N, size=4):
    if size == 4:
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2)]

        # middle squares
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)]

        
    if size==8 :
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0), (1,1)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1), (1, N - 2)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0), (M - 2, 1)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1), (M - 2,N - 2)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j), (1, j+1), (1, j-1)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j),(M-2,j-1),(M-2,j+1)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1),(i-1,1),(i+1,1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2),(i+1,N-2),(i+1,N-2)]

        # middle squares
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1),(i-1,j-1),(i-1,j+1),(i+1,j-1),(i+1,j+1)]
    
    return n

def variational_bayes(y,max_iters,num_neighs):
    w_ij = 1
    
    im_noisy = np.copy(y) * 2 - 1

    
    for t in range(max_iters):
        for j in range(im_noisy.shape[0]):
            for i in range(im_noisy.shape[1]):
                neighs = neighbours(j, i, im_noisy.shape[0], im_noisy.shape[1], num_neighs)
                m = sum(w_ij * im_noisy[n_j, n_i] for n_j, n_i in neighs)
                
                im_noisy[j, i] = np.tanh(m + 0.5*(im_noisy[j, i] - im_noisy[j, i]))
                
    return im_noisy

im_out = variational_bayes(SnP_Noise_Image,5 , 4)
im_out1 = variational_bayes(SnP_Noise_Image,5 , 8)

ax = fig.add_subplot(153)
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.imshow(im_out, cmap='gray')
ax.set_title('4Neighs')

ax = fig.add_subplot(154)
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.imshow(im_out1, cmap='gray')
ax.set_title('8 Neighs')
plt.show()