#Gibbs Sampler - question 2. Need to implement 3(starting from a random point) and 4 (increasing/decreasing no. of runs)
import cv2
import numpy as np
import matplotlib.pyplot as plt
from Gaussian_Noise import Gaussian_Noise_method
from SaltNPepperNoise import SaltNPepper_Noise_method

error_proportion = 0.3
sigma_variance = 0.1

Original_image = cv2.imread('pug.png',cv2.IMREAD_GRAYSCALE)
Original_image = Original_image/255.0
Original_image[Original_image<0.5]=-1
Original_image[Original_image>=0.5]=1
fig = plt.figure()
ax = fig.add_subplot(151)
ax.imshow(Original_image, cmap='gray')
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.set_title('original')

'''
Gaussian_Noise_Image = Gaussian_Noise_method(Original_image, error_proportion, sigma_variance)
ax = fig.add_subplot(152)
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.imshow(Gaussian_Noise_Image, cmap='gray')
ax.set_title('gaussian')'''

SnP_Noise_Image = SaltNPepper_Noise_method(Original_image, error_proportion)
ax = fig.add_subplot(152)
ax.imshow(SnP_Noise_Image, cmap='gray')
ax.set_title('Salt N Pepper')
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)



def neighbours(i, j, M, N, size=4):
    if size == 4:
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2)]

        # middle squares
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)]

        
    if size==8 :
        # corners
        if i == 0 and j == 0:
            n = [(0, 1), (1, 0), (1,1)]
        elif i == 0 and j == N - 1:
            n = [(0, N - 2), (1, N - 1), (1, N - 2)]
        elif i == M - 1 and j == 0:
            n = [(M - 1, 1), (M - 2, 0), (M - 2, 1)]
        elif i == M - 1 and j == N - 1:
            n = [(M - 1, N - 2), (M - 2, N - 1), (M - 2,N - 2)]

        # edges
        elif i == 0:
            n = [(0, j - 1), (0, j + 1), (1, j), (1, j+1), (1, j-1)]
        elif i == M - 1:
            n = [(M - 1, j - 1), (M - 1, j + 1), (M - 2, j),(M-2,j-1),(M-2,j+1)]
        elif j == 0:
            n = [(i - 1, 0), (i + 1, 0), (i, 1),(i-1,1),(i+1,1)]
        elif j == N - 1:
            n = [(i - 1, N - 1), (i + 1, N - 1), (i, N - 2),(i+1,N-2),(i+1,N-2)]

        # middle squares
        else:
            n = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1),(i-1,j-1),(i-1,j+1),(i+1,j-1),(i+1,j+1)]
    
    return n

def finding_likelihood(j, i, X, Y, prob):
    xi = X[j][i] + 1 / 2 #scale x_i to be in [0, 1]
    yi = Y[j][i]
    
    # if li is 0 (xi=yi) so e^0 is 1 
    Li = - np.abs(xi - yi) * prob
    return np.exp(Li)

def prior_evaluation(j, i, X, M, N, w):
    #p(x) = 1/Z0.e^E_0(x)
    
    # get the neighbours of x_ij
    neighs = neighbours(j, i, M, N,4)
    
    
    total = 0
    for neigh_j, neigh_i in neighs:
        total += w * X[j, i] * X[neigh_j, neigh_i]
        
        # ... then for each neighbour, we do the same
        for neigh_jj, neigh_ii in neighbours(neigh_j, neigh_i, M, N):
            total += w * X[neigh_j, neigh_i] * X[neigh_jj, neigh_ii]
    
    return np.exp(total)

def find_posterior(j, i, x_value, X, Y, M, N):
    X[j][i] = x_value
    
    # calculate finding_likelihood , keep 1 as having every value equally likely
    prob = 1
    likelihood_val = finding_likelihood(j, i, X, Y, prob)
    
    # calculate prior_evaluation , keep a 70% belief on the prior_evaluation assumptions
    w = 0.7
    prior_val      = prior_evaluation(j, i, X, M, N, w)
    
    return likelihood_val * prior_val

def Gibbs_IsingModel_Posterior(j, i, X, Y, M, N):
    like_prior   = find_posterior(j, i, 1, X, Y, M, N) #xi=1
    evidence = like_prior + find_posterior(j, i, -1, X, Y, M, N) #xi=1 and xi=-1
    
    return like_prior / evidence
    

def Gibbs_Sampling_Method(Y, Iterations, Burn_Values):
    X_t = np.copy(Y)
    
    # get dim(X)
    M = X_t.shape[0] # rows (j)
    N = X_t.shape[1] # cols (i)
    
    # for Iterations iterations
    avg = np.zeros_like(X_t).astype(np.float64)
    for t in range(Iterations + Burn_Values):
        for j in range(M):
            for i in range(N):
                
                # sample from find_posterior p(x_i = 1 | x_not_i, y)
                prob_t = Gibbs_IsingModel_Posterior(j, i, X_t, Y, M, N)
                z = np.random.uniform(0, 1)
                if prob_t > z:
                    X_t[j, i] = 1
                else:
                    X_t[j, i] = -1
                
                # add to avg if we've finished burning in
                if t > Burn_Values:
                    avg += X_t
    
    return avg / Iterations
    
np.random.seed(42)
im_out = Gibbs_Sampling_Method(SnP_Noise_Image,1,1)
im_out[im_out >= 0] = 1
im_out[im_out < 0]  = -1
ax = fig.add_subplot(153)
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
ax.imshow(im_out, cmap='gray')
ax.set_title('4Neighs')

plt.show()