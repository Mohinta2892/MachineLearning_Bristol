import cv2
import numpy as np

def Gaussian_Noise_method(original_image, error_proportion, sigma_variance):
    N = int(np.round(np.prod(original_image.shape) * error_proportion))

    index = np.unravel_index(np.random.permutation(np.prod(original_image.shape))[1:N], original_image.shape)
    e = sigma_variance * np.random.randn(np.prod(original_image.shape)).reshape(original_image.shape)
    Gaussian_Noise_Image = np.copy(original_image).astype('float')
    Gaussian_Noise_Image[index] += e[index]

    return Gaussian_Noise_Image
